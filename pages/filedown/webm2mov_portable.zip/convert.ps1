﻿# ============================================================
#  webm(VP9+Alpha) -> MOV(ProRes 4444 XQ) 便携版 v3
#  v3: 转换前打印完整ffmpeg命令行(写入convert_log.txt，便于与py版对比)
#  编码参数与原 Python 脚本完全一致
# ============================================================
$ErrorActionPreference = 'Continue'

$Root    = $PSScriptRoot
$BinDir  = Join-Path $Root 'bin'
$Ffmpeg  = Join-Path $BinDir 'ffmpeg.exe'
$Ffprobe = Join-Path $BinDir 'ffprobe.exe'
$ProresQ = 11
$LogFile = Join-Path $Root 'convert_log.txt'

$WorkDir = $Root
if ($args.Count -gt 0 -and (Test-Path -LiteralPath $args[0])) {
    $WorkDir = (Resolve-Path -LiteralPath $args[0]).Path
}
$OutputDir = Join-Path $WorkDir 'mov_output'

if (-not (Test-Path -LiteralPath $Ffmpeg))  { Write-Host '[X] 未找到 bin\ffmpeg.exe ！' -ForegroundColor Red; exit 1 }
if (-not (Test-Path -LiteralPath $Ffprobe)) { Write-Host '[X] 未找到 bin\ffprobe.exe ！' -ForegroundColor Red; exit 1 }

function Get-PixFmt([string]$path) {
    try {
        $o = & $Ffprobe -v error -select_streams v:0 -show_entries stream=pix_fmt -of csv=p=0 -- $path 2>$null
        if ($null -ne $o) { return "$o".Trim() }
    } catch {}
    return ''
}

function Get-Duration([string]$path) {
    try {
        $o = & $Ffprobe -v error -show_entries format=duration -of csv=p=0 -- $path 2>$null
        return [double]::Parse("$o".Trim(), [Globalization.CultureInfo]::InvariantCulture)
    } catch { return 0.0 }
}

function New-FfmpegArgs([string]$inPath, [string]$outPath) {
    $a = @(
        '-y',
        '-vcodec', 'libvpx-vp9',   # ← 新增：强制VP9解码器，确保Alpha通道被正确读取
        '-i', $inPath,
        '-c:v', 'prores_ks',
        '-profile:v', '4444xq',
        '-pix_fmt', 'yuva444p10le',
        '-q:v', "$ProresQ",
        '-vendor', 'apl0',
        '-c:a', 'aac',
        '-b:a', '64k',
        '-movflags', '+faststart',
        '-progress', 'pipe:1',
        '-nostats',
        '-loglevel', 'error',
        $outPath
    )
    return (($a | ForEach-Object {
        if ($_ -match '[\s"]') { '"' + ($_ -replace '"', '\"') + '"' } else { $_ }
    }) -join ' ')
}


$files = @(Get-ChildItem -LiteralPath $WorkDir -Filter '*.webm' -File | Sort-Object Name)
if ($files.Count -eq 0) {
    Write-Host "[!] 在 $WorkDir 下没有找到 .webm 文件" -ForegroundColor Yellow
    exit 0
}

New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
"=== 转换日志 $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ===" | Out-File -FilePath $LogFile -Encoding utf8

Write-Host ''
Write-Host ("[*] 共转换 {0} 个文件 | ProRes 4444 XQ q:v={1} | 输出: mov_output\" -f $files.Count, $ProresQ) -ForegroundColor Cyan
Write-Host ("[*] ffmpeg: {0}" -f $Ffmpeg) -ForegroundColor DarkGray
Write-Host ('-' * 60)

$i = 0
$failed = @()
$swAll = [Diagnostics.Stopwatch]::StartNew()
$barLen = 30

foreach ($f in $files) {
    $i++
    $outPath = Join-Path $OutputDir ([IO.Path]::ChangeExtension($f.Name, 'mov'))
    $dur = Get-Duration $f.FullName
    $argLine = New-FfmpegArgs $f.FullName $outPath

    Write-Host ("[{0}/{1}] {2}" -f $i, $files.Count, $f.Name) -ForegroundColor Cyan
    Write-Host ("    $argLine") -ForegroundColor DarkGray
    $argLine | Out-File -FilePath $LogFile -Append -Encoding utf8

    $inFmt = Get-PixFmt $f.FullName
    if ($inFmt -and $inFmt -notlike 'yuva*') {
        Write-Host ("    [提示] 输入视频流格式为 {0}，未检测到Alpha通道" -f $inFmt) -ForegroundColor DarkYellow
    }

    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = $Ffmpeg
    $psi.Arguments = $argLine
    $psi.UseShellExecute = $false
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $false
    $psi.CreateNoWindow = $true

    $sw = [Diagnostics.Stopwatch]::StartNew()
    $proc = [Diagnostics.Process]::Start($psi)
    $lastPct = -1

    try {
        while (-not $proc.StandardOutput.EndOfStream) {
            $line = $proc.StandardOutput.ReadLine()
            if ($null -eq $line) { break }
            $sec = -1.0
            if ($line -match '^out_time=(\d+):(\d+):(\d+\.?\d*)') {
                $sec = [int]$matches[1] * 3600 + [int]$matches[2] * 60 + [double]$matches[3]
            } elseif ($line -match '^out_time_ms=(\d+)') {
                $sec = [double]$matches[1] / 1000000.0
            }
            if ($sec -ge 0) {
                if ($dur -gt 0) {
                    $pct = [Math]::Min(100, [int]($sec / $dur * 100))
                    if ($pct -gt $lastPct) {
                        $lastPct = $pct
                        $filled = [int]($barLen * $pct / 100)
                        $bar = ('#' * $filled) + ('.' * ($barLen - $filled))
                        Write-Host -NoNewline ("`r    [{0}] {1,3}%  {2,7:0.0}s / {3:0.0}s   " -f $bar, $pct, $sec, $dur)
                    }
                } else {
                    Write-Host -NoNewline ("`r    转码中... {0:0.0}s   " -f $sec)
                }
            }
        }
        $proc.WaitForExit()
    } catch {
        if (-not $proc.HasExited) { try { $proc.Kill() } catch {} }
    }
    Write-Host ''

    if ($proc.ExitCode -eq 0) {
        $fmt = Get-PixFmt $outPath
        if ($fmt -like 'yuva*') {
            Write-Host ("    [OK] 转换完成 ({0:0.0}秒) | Alpha通道: 已保留 [{1}]" -f $sw.Elapsed.TotalSeconds, $fmt) -ForegroundColor Green
        } elseif ($fmt) {
            Write-Host ("    [OK] 转换完成 ({0:0.0}秒) | [!] 输出格式 {1} 不含Alpha，请运行 ab_test.cmd 排查" -f $sw.Elapsed.TotalSeconds, $fmt) -ForegroundColor Yellow
        } else {
            Write-Host ("    [OK] 转换完成 ({0:0.0}秒) | [!] 输出文件无法读取，可能损坏，请运行 ab_test.cmd" -f $sw.Elapsed.TotalSeconds) -ForegroundColor Yellow
        }
    } else {
        Write-Host ("    [FAIL] 转换失败 (exit={0})" -f $proc.ExitCode) -ForegroundColor Red
        $failed += $f.Name
    }
    $proc.Dispose()
}

$swAll.Stop()
Write-Host ('-' * 60)
Write-Host ("[*] 全部完成！总耗时 {0:0.0} 秒 | 成功: {1} | 失败: {2}" -f `
    $swAll.Elapsed.TotalSeconds, ($files.Count - $failed.Count), $failed.Count) -ForegroundColor Cyan
Write-Host ("[*] 命令行日志: {0}" -f $LogFile) -ForegroundColor DarkGray

if ($failed.Count -gt 0) {
    Write-Host ''
    Write-Host '[!] 转换失败的文件：' -ForegroundColor Red
    foreach ($n in $failed) { Write-Host "    $n" }
    exit 1
}
exit 0
