@echo off
rem webm -> mov (ProRes 4444 XQ) portable launcher
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0convert.ps1" %*
pause
